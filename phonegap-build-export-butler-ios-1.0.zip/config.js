define( function ( require ) {

	"use strict";

	return {
		app_slug : 'butler-ios',
		wp_ws_url : 'https://saimaaglamping.com/wp-appkit-api/butler-ios',
		wp_url : 'https://saimaaglamping.com',
		theme : 'q-ios',
		version : '1.0',
		app_type : 'phonegap-build',
		app_title : 'Butler',
		app_platform : 'ios',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : ',acL20|xsnEI/sFM[zz?=@uXr@E-u:qLBlXxB{#]~WYhh<U29s1|}DuB5)D(Ql%W',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
